package com.eccelor.mauck.taa.abc_generalstore.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.eccelor.mauck.taa.abc_generalstore.model.Product;
import com.eccelor.mauck.taa.abc_generalstore.model.Item;
import java.util.ArrayList;

/**
 * Created by ECLR-01 on 06-10-2017.
 */

public class Database extends SQLiteOpenHelper
{

    String TableProduct = "Product", id = "id", ProductName = "ProductName";

    String TableItem = "Item", ItemName = "ItemName", ItemQuantity = "ItemQuantity", ItemPrice = "ItemPrice";

    public Database(Context context)
    {
        super(context, "ABC", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase)
    {
        String food = " create table " + TableProduct + "("
                + id + " integer primary key autoincrement, "
                + ProductName + " text)";
        sqLiteDatabase.execSQL(food);

        String item = " create table " + TableItem + "("
                + ItemName + " text, "
                + ItemQuantity + " text, "
                + ItemPrice + " text)";
        sqLiteDatabase.execSQL(item);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1)
    {

    }

    public void insertProduct(Product product)
    {
        SQLiteDatabase database = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(ProductName, product.getProductName());
        database.insert(TableProduct,null,contentValues);
        database.close();
    }


    public void insertItem(Item item)
    {
        SQLiteDatabase database = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(ItemName,item.getItem_name());
        contentValues.put(ItemQuantity,item.getItem_quantity());
        contentValues.put(ItemPrice,item.getItem_price());
        database.insert(TableItem,null,contentValues);
        database.close();
    }

    public ArrayList<Product> display_ProductName()
    {
        ArrayList<Product> arrayList=new ArrayList<>();
        SQLiteDatabase database = getReadableDatabase();
        String sql = " select * from " + TableProduct;
        Cursor cursor = database.rawQuery(sql,null);

        while (cursor.moveToNext())
        {
            Product product = new Product();
            product.setId(cursor.getString(0));
            product.setProductName(cursor.getString(1));
            arrayList.add(product);
        }
        database.close();
        return arrayList;
    }

    public ArrayList<Item> display_ItemName()
    {
        ArrayList<Item> arrayList=new ArrayList<>();
        SQLiteDatabase database = getReadableDatabase();
        String sql = " select * from " + TableItem;
        Cursor cursor = database.rawQuery(sql,null);

        while (cursor.moveToNext())
        {
            Item item = new Item();
            item.setItem_name(cursor.getString(0));
            item.setItem_quantity(cursor.getString(1));
            item.setItem_price(cursor.getString(2));
            arrayList.add(item);
        }
        database.close();
        return arrayList;
    }

    public void Update_Product(Product product)
    {
        SQLiteDatabase database = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(ProductName, product.getProductName());
        database.update(TableProduct,contentValues,id+"="+product.getId(),null);
        database.close();
    }
    public void Delete_ProductName(String id)
    {
        SQLiteDatabase database=getReadableDatabase();
        database.delete(TableProduct,this.id+"="+id,null);
        database.close();
    }
}

