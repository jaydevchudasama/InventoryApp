package com.eccelor.mauck.taa.abc_generalstore;

import android.app.Dialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatEditText;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ListView;
import com.eccelor.mauck.taa.abc_generalstore.adapter.ListItemAdapter;
import com.eccelor.mauck.taa.abc_generalstore.database.Database;
import com.eccelor.mauck.taa.abc_generalstore.model.Item;
import java.util.ArrayList;


public class FoodActivity extends AppCompatActivity
{

    ListView listView;
    ArrayList<Item> arrayList;

    private AppCompatButton AddItem;
    private AppCompatButton SellItem;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food);

        listView = findViewById(R.id.listItem);
        AddItem = findViewById(R.id.btnAdditem);
        SellItem = findViewById(R.id.btnSellitem);

        Database database = new Database(FoodActivity.this);
        arrayList=new ArrayList<>();
        arrayList = database.display_ItemName();

        listView.setAdapter(new ListItemAdapter(FoodActivity.this,arrayList));




       View.OnClickListener clickListener = new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                switch (view.getId())
                {
                    case R.id.btnAdditem:
                        final Dialog dialog=new Dialog(FoodActivity.this);
                        dialog.setContentView(R.layout.partial_item_name);
                        final AppCompatEditText textItemName = dialog.findViewById(R.id.textItemName);
                        final AppCompatEditText textItemQuantity = dialog.findViewById(R.id.textItemQuantity);
                        final AppCompatEditText textItemPrice = dialog.findViewById(R.id.textItemPrice);
                        AppCompatButton Add = dialog.findViewById(R.id.btnAdd);

                        Add.setOnClickListener(new View.OnClickListener()
                        {
                            @Override
                            public void onClick(View view)
                            {
                                String itemName=textItemName.getText().toString();
                                String quantity=textItemQuantity.getText().toString();
                                String price=textItemPrice.getText().toString();
                                if (TextUtils.isEmpty(itemName))
                                {
                                    textItemName.setError("Enter ItemName");
                                    textItemName.requestFocus();
                                    return;
                                }
                                if (TextUtils.isEmpty(quantity))
                                {
                                    textItemQuantity.setError("Enter Quanity");
                                    textItemQuantity.requestFocus();
                                    return;
                                }
                                if (TextUtils.isEmpty(price))
                                {
                                    textItemPrice.setError("Enter Price");
                                    textItemPrice.requestFocus();
                                    return;
                                }
                                else {

                                    Item item = new Item();
                                    item.setItem_name(textItemName.getText().toString());
                                    item.setItem_quantity(textItemQuantity.getText().toString());
                                    item.setItem_price(textItemPrice.getText().toString());

                                    Database database = new Database(FoodActivity.this);
                                    database.insertItem(item);
                                    Intent intent = new Intent(FoodActivity.this,FoodActivity.class);
                                    startActivity(intent);
                                    finish();
                                    dialog.dismiss();

                                }
                            }
                        });
                        dialog.show();
                        break;
                }
            }
        };
       AddItem.setOnClickListener(clickListener);

    }
}
