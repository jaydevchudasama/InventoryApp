package com.eccelor.mauck.taa.abc_generalstore;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class AddItemActivity extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);
    }
}
