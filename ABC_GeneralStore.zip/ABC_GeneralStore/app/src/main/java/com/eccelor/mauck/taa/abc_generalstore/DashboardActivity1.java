package com.eccelor.mauck.taa.abc_generalstore;

import android.app.Dialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatEditText;
import android.text.TextUtils;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;
import com.eccelor.mauck.taa.abc_generalstore.adapter.ListProductAdapter;
import com.eccelor.mauck.taa.abc_generalstore.database.Database;
import com.eccelor.mauck.taa.abc_generalstore.model.Product;
import java.util.ArrayList;

public class DashboardActivity1 extends AppCompatActivity
{

    ListView listView;
    ArrayList<Product> arrayList;

    AppCompatButton Product;
    AppCompatButton Report;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        listView = findViewById(R.id.listProduct);
        Product = findViewById(R.id.btnProduct);
        Report = findViewById(R.id.btnReport);
        registerForContextMenu(listView);

        Database database=new Database(DashboardActivity1.this);
        arrayList = new ArrayList<>();
        arrayList = database.display_ProductName();


        listView.setAdapter(new ListProductAdapter(DashboardActivity1.this,arrayList));

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l)
            {
                startActivity(new Intent(DashboardActivity1.this,FoodActivity.class));
            }
        });

        View.OnClickListener clickListener=new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {

                switch (view.getId())
                {
                    case R.id.btnProduct:
                        final Dialog dialog=new Dialog(DashboardActivity1.this);
                        dialog.setContentView(R.layout.partial_product_name);
                        final AppCompatEditText ProductName = dialog.findViewById(R.id.textProductName);
                        AppCompatButton Add = dialog.findViewById(R.id.btnAdd);

                        Add.setOnClickListener(new View.OnClickListener()
                        {
                            @Override
                            public void onClick(View view)
                            {
                                String name=ProductName.getText().toString();
                                if (TextUtils.isEmpty(name))
                                {
                                    ProductName.setError("Enter ProductName");
                                    ProductName.requestFocus();
                                    return;
                                }else {
                                    com.eccelor.mauck.taa.abc_generalstore.model.Product product = new Product();

                                    product.setProductName(ProductName.getText().toString());
                                    Database database = new Database(DashboardActivity1.this);
                                    database.insertProduct(product);

                                    Intent intent = new Intent(DashboardActivity1.this,DashboardActivity1.class);
                                    startActivity(intent);
                                    finish();
                                    Toast.makeText(DashboardActivity1.this, "Add Procudt", Toast.LENGTH_SHORT).show();
                                    dialog.dismiss();
                                }
                            }
                        });
                        dialog.show();
                        Toast.makeText(DashboardActivity1.this, "Click Report", Toast.LENGTH_SHORT).show();

                    break;

                    case R.id.btnReport:

                    break;
                }
            }
        };
        Product.setOnClickListener(clickListener);
        Report.setOnClickListener(clickListener);
    }

    @Override
    public void onBackPressed()
    {
        super.onBackPressed();
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        menu.add("List");
        menu.add("Grocery");
        menu.add("Novelty");
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        if (item.getTitle().equals("List"))
        {
            Intent intent =  new Intent(DashboardActivity1.this,ProductListActivity.class);
            startActivity(intent);
            Toast.makeText(this, "Food", Toast.LENGTH_SHORT).show();
        }
        else if (item.getTitle().equals("Grocery"))
        {
            Toast.makeText(this, "Grocery", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(this, "Novelty", Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo)
    {
        menu.add("Delete Product");
        menu.add("Update Product");
        super.onCreateContextMenu(menu, v, menuInfo);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item)
    {
        AdapterView.AdapterContextMenuInfo adapterContextMenuInfo=(AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
        int position=adapterContextMenuInfo.position;

        Product product=arrayList.get(position);

        if (item.getTitle().equals("Delete Product"))
        {
            Database database=new Database(DashboardActivity1.this);
            database.Delete_ProductName(product.getId());

            arrayList = database.display_ProductName();
            listView.setAdapter(new ListProductAdapter(DashboardActivity1.this,arrayList));

            Toast.makeText(this, "Item Delete", Toast.LENGTH_SHORT).show();
        }
        if (item.getTitle().equals("Update Product"))
        {
            Toast.makeText(this, "Item Update", Toast.LENGTH_SHORT).show();
        }
        return super.onContextItemSelected(item);
    }
}
