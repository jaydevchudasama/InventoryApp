package com.eccelor.mauck.taa.abc_generalstore;

import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toolbar;

import com.eccelor.mauck.taa.abc_generalstore.adapter.ListProductAdapter;
import com.eccelor.mauck.taa.abc_generalstore.database.Database;
import com.eccelor.mauck.taa.abc_generalstore.model.Product;
import java.util.ArrayList;


public class ProductListActivity extends AppCompatActivity
{

    ArrayList<Product> arrayList;
    ListView listView;
    Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        ActionBar actionBar=getSupportActionBar();
        actionBar.hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_list);

        toolbar = findViewById(R.id.toolbar);

        getSupportActionBar();
        listView = findViewById(R.id.ProductListshow);
        Database database = new Database(ProductListActivity.this);
        arrayList = database.display_ProductName();

        Log.e("size",arrayList.size()+"");
        listView.setAdapter(new ListProductAdapter(ProductListActivity.this,arrayList));


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l)
            {
                startActivity(new Intent(ProductListActivity.this,AddItemActivity.class));
                finish();
            }
        });
    }
}
